# Java IV — Faqja e një punëtorie studentore

**Programimi në Web · HTML dhe CSS**


## Çfarë do të ndërtoni

Një faqe të vetme për punëtorinë imagjinare **“Fotografia me telefon”**: informacioni i aktivitetit, programi dhe formulari i interesimit. Asistenti demonstron fillimisht një faqe të ngjashme për “Klubin e leximit”.

**Pamja e pritur:** sfond gri i çelët; përmbajtje e përqendruar me gjerësi maksimale 680px; titull blu; tri kuti të bardha njëra poshtë tjetrës; etiketa dhe fusha formulari në rreshta të veçantë; buton blu. Edhe në desktop kutitë mbeten vertikale. Nuk kërkohen kolona, Grid, Flexbox, media queries ose JS.

## Leximi paraprak — Deitel, botimi V

Libri: Paul, Harvey dhe Abbey Deitel, *Internet & World Wide Web: How to Program*, Fifth Edition.

**Kapitulli 4: Introduction to Cascading Style Sheets (CSS): Part 1.** Shfletoni:

- 4.3 — Embedded Style Sheets: sintaksa e rregullave dhe selektorëve; në ushtrim rregullat vendosen në skedar të jashtëm.
- 4.4 — Conflicting Styles: si ndikojnë rregullat mbi të njëjtin element.
- 4.5 — Linking External Style Sheets: lidhja HTML–CSS.
- 4.8 — Backgrounds: sfondi.
- 4.9 — Element Dimensions: gjerësia e elementeve.
- 4.10 — Box Model and Text Flow: margin, padding dhe border.


## 1. Fillimi

Kopjoni përmbajtjen e [Fillimi/](Fillimi/) në JavaIV/ të repos suaj. Punoni në index.html dhe style.css. HTML ka skelet dhe komente TODO; CSS ka vetëm udhëzime për rregullat që duhen shkruar.

## 2. Kërkesat HTML

1. Ruani lang, charset dhe viewport. Vendosni title dhe h1: **Fotografia me telefon**.
2. Nën titull vendosni: “Mëso të krijosh fotografi më të qarta me telefonin tënd.”
3. Te kutia **Rreth punëtorisë** vendosni: “E shtunë, ora 11:00 · Salla e aktiviteteve”. Shtoni paragrafin “Punëtori për fillestarë. Merr telefonin dhe një objekt të vogël për fotografim.”
4. Te kutia **Programi**, krijoni listë ul me tri pika: Drita natyrale; Kompozimi; Ushtrimi praktik.
5. Te kutia **Shpreh interesimin**, krijoni form me action="index.html" dhe method="get": emri (text, required), emaili (email, required), përvoja (select, required, opsion fillestar bosh, pastaj Fillestar dhe Kam provuar më herët), butoni submit “Dërgo interesimin”. Çdo fushë ka id, name dhe label me for përkatës.
6. Nën formular shkruani “Vetëm demonstrim: të dhënat nuk ruhen.” Përdorni të dhëna të sajuara kur e provoni.
7. Në footer vendosni “Punuar nga: Emri Mbiemri”. Nuk nevojiten imazhe, faqe të tjera ose shkarkime.

## 3. Kërkesat CSS — shkruani këto rregulla në style.css

Lidhja në head duhet të jetë `<link rel="stylesheet" href="style.css">`. Nuk përdoren stile inline.

| Selektori | Vetitë dhe vlerat e kërkuara | Çfarë duhet të shihni |
|---|---|---|
| `*` | `box-sizing: border-box` | Padding/border përfshihen në gjerësinë e kutisë |
| `body` | `margin: 0; font-family: Arial, sans-serif; font-size: 16px; line-height: 1.5; color: #243247; background-color: #eef2f6` | Sfond i çelët, tekst i lexueshëm |
| `.faqja` | `width: 100%; max-width: 680px; margin: 0 auto; padding: 20px` | Përmbajtje në mes, me hapësirë anash në telefon |
| `h1` | `font-size: 28px; color: #174a7e; margin: 0 0 12px` | Titull blu, hapësirë poshtë |
| `h2` | `font-size: 20px; margin: 0 0 12px` | Nëntituj më të vegjël |
| `.hyrja` | `margin: 0 0 20px` | Hapësirë mes hyrjes dhe kutisë së parë |
| `.kuti` | `background-color: white; border: 1px solid #bcc9d6; padding: 20px; margin-bottom: 16px` | Tri kuti të dallueshme, vertikale |
| `ul` | `padding-left: 24px` | Lista mbetet brenda kutisë |
| `label` | `display: block; font-weight: bold; margin-bottom: 6px` | Etiketa mbi fushë |
| `input, select` | `display: block; width: 100%; font: inherit; padding: 10px; border: 1px solid #64748b; margin-bottom: 14px` | Fusha të plota brenda kutisë |
| `button` | `font: inherit; background-color: #174a7e; color: white; padding: 10px 16px; border: 0; cursor: pointer` | Buton blu me tekst të bardhë |
| `button:hover` | `background-color: #103452` | Sfond më i errët kur kalon miu |
| `input:focus-visible, select:focus-visible, button:focus-visible` | `outline: 3px solid #a34b00; outline-offset: 2px` | Fokusi shihet me Tab |
| `.shenim, footer` | `font-size: 14px; color: #475569` | Shënimi dhe autori janë më të vegjël |

Mos e zëvendësoni max-width me width:680px; ai do të nxirrte faqen jashtë ekranit të telefonit. Margin është jashtë kufirit të kutisë, padding brenda tij. Mos përdorni overflow-x:hidden për të fshehur gabimet.

## 4. Kontrolli para dorëzimit

- [ ] Ka tri kuti në rendin: Rreth punëtorisë, Programi, Shpreh interesimin.
- [ ] Në 1000px përmbajtja është në mes dhe kutitë mbeten njëra poshtë tjetrës.
- [ ] Në 360px nuk ka scroll horizontal; fushat dhe butoni janë brenda kutisë.
- [ ] CSS ngarkohet: ndryshimi i ngjyrës së h1 shihet pas Save/refresh.
- [ ] Klikimi i etiketës aktivizon fushën; Tab tregon fokusin.
- [ ] Formulari bosh, emaili pa @ dhe përvoja e pazgjedhur nuk pranohen.
- [ ] Me të dhëna të sakta, dërgimi hap index.html me parametrat në adresë; kjo nuk është ruajtje në server.

Në README.md tuaj shkruani: çfarë bën link rel="stylesheet"; dallimin margin/padding; pse përdoret max-width; rezultatet e testimit në 360 dhe 1000px.

