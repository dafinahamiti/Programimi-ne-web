# Fillimi — Java IV

Kopjoni index.html dhe style.css në JavaIV/ të repos suaj. Lexoni kërkesat në ../README.md të paketës së ushtrimeve. Plotësoni TODO-t në HTML, pastaj shkruani CSS sipas tabelës. Në këtë README shkruani shpjegimet dhe rezultatet reale të testeve që kërkohen. Nuk kërkohet punimi i javëve të kaluara.
